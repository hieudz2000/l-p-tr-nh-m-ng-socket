

#include <stdio.h>
#include <strings.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#define MAXLINE 1000

static int k = 0;
int split(char *buffer, char *only_number, char *only_string)
{
	strcpy(only_string, buffer);
	int k = 0;
	strcpy(only_number, buffer);
	int j = 0;
	int m = 0;
	for (int i = 0; i < 100; i++)
	{
		char ch = only_number[i];
		if (ch == '\0')
			break;
		if (ch >= '0' && ch <= '9')
		{
			only_number[j] = ch;
			j++;
		}
		else if ((ch >= 'a' && ch <= 'z') || (ch == ' '))
		{
			only_string[k] = ch;
			k++;
		}
		else
		{
			return 0;
		}
	}
	only_number[j] = '\0';
	only_string[k] = '\0';
	return 1;
}

int main(int argc, char *argv[])
{
	if (argc == 1)
	{
		printf("Please input port number\n");
		return 0;
	}
	char *port_number = argv[1];
	int port = atoi(port_number);
	char buffer1[100];
	char buffer2[100];
	char only_string[100];
	char only_number[100];
	int listenfd, len1, len2;
	struct sockaddr_in servaddr, cliaddr1, cliaddr2;
	bzero(&servaddr, sizeof(servaddr));
	listenfd = socket(AF_INET, SOCK_DGRAM, 0);
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(port);
	servaddr.sin_family = AF_INET;

	// bind server address to socket descriptor
	bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
	while (1)
	{
		len1 = sizeof(cliaddr1);
		len2 = sizeof(cliaddr2);
		int n1 = recvfrom(listenfd, buffer1, sizeof(buffer1), 0, (struct sockaddr *)&cliaddr1, &len1);
		int n2 = recvfrom(listenfd, buffer2, sizeof(buffer2), 0, (struct sockaddr *)&cliaddr2, &len2);
		buffer1[n1] = '\0';
		
		if (split(buffer1, only_number, only_string) == 1)
		{
			strcat(only_number, "\n");
			strcat(only_number, only_string);
		}
		else
		{
			strcpy(only_number, "Error");
			strcpy(only_string, "");
		}

		sendto(listenfd, only_number, MAXLINE, 0, (struct sockaddr *)&cliaddr2, sizeof(cliaddr2));

		if (split(buffer2, only_number, only_string) == 1)
		{
			strcat(only_number, "\n");
			strcat(only_number, only_string);
		}
		else
		{
			strcpy(only_number, "Error");
			strcpy(only_string, "");
		}

		sendto(listenfd, only_number, MAXLINE, 0, (struct sockaddr *)&cliaddr1, sizeof(cliaddr1));
		// printf(" client1:  [%s:%d]: \n", inet_ntoa(cliaddr1.sin_addr), ntohs(cliaddr1.sin_port) );
		// printf("client2:  [%s:%d]: \n", inet_ntoa(cliaddr2.sin_addr), ntohs(cliaddr2.sin_port) );
	}
}