//
// Created by hainguyen on 30/12/2021.
//

#ifndef LTM_PROJECT_ROOMCONTROLLER_H
#define LTM_PROJECT_ROOMCONTROLLER_H

#include "structScreen.h"
#include "handleMain.h"

void on_start_button_clicked(GtkButton *button, UserData *userData);
void on_out_button_clicked(GtkButton *button,UserData *userData);



#endif //LTM_PROJECT_ROOMCONTROLLER_H
