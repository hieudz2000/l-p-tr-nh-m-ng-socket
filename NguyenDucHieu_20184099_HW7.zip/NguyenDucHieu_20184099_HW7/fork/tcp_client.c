#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>

#define SERVER_ADDR "127.0.0.1"
#define SERVER_PORT 5500
#define BUFF_SIZE 1024

char buffer[BUFF_SIZE + 1];
char mes[BUFF_SIZE + 1];
char mes1[BUFF_SIZE + 1];
int xuli()
{
	memset(mes, '\0', (strlen(mes) + 1));
	if (strstr(buffer, ".txt") == NULL)
	{

		printf("Error: Wrong file format");

		return 1;
	}
	FILE *fp = fopen(buffer, "r");
	if (fp == NULL)
	{
		printf("%s\n", buffer);
		printf("khong co file");
		return 3;
	}
	else
	{
		fclose(fp);
	}

	int k = 0;
	strcpy(mes1, buffer);

	for (int i = 0; i < strlen(buffer); i++)
	{
		if (buffer[i] == '/')
		{
			for (int j = i; j < strlen(buffer) - 1; j++)
			{
				buffer[j] = buffer[j + 1];
			}
			buffer[strlen(buffer) - 1] = '\0';
		}
	}

	return 0;
}
char ab[10000];
long long k;
int xuli2()
{
	FILE *fp = fopen(mes1, "r");

	fseek(fp, 0, SEEK_END);
	k = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	fread(ab, k + 1, 1, fp);
	fclose(fp);
}

int main()
{
	int client_sock;

	struct sockaddr_in server_addr; /* server's address information */
	int msg_len, bytes_sent, bytes_received;
	client_sock = socket(AF_INET, SOCK_STREAM, 0);

	//Step 2: Specify server address
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = inet_addr(SERVER_ADDR);

	if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0)
	{
		printf("\nError!Can not connect to sever! Client exit imediately! ");
		return 0;
	}
	do
	{
		memset(buffer, '\0', (strlen(buffer) + 1));
		printf("\nInsert path of file to send:");
		fgets(buffer, BUFF_SIZE, stdin);
		buffer[strlen(buffer) - 1] = '\0';
	} while (xuli() != 0);
	xuli2();

	int byte;
	bytes_sent = send(client_sock, buffer, strlen(buffer), 0);

	byte = send(client_sock, ab, strlen(ab), 0);
	if (bytes_sent < 0)
		perror("\nError: ");
	if (byte < 0)
		perror("\nError: ");
	printf("so bytes gui toi server: %lld\n", k);
	memset(buffer, '\0', (strlen(buffer) + 1));
	bytes_received = recv(client_sock, buffer, BUFF_SIZE, 0);
	printf("%s", buffer);
	close(client_sock);
	return 0;

	//receive echo reply
}