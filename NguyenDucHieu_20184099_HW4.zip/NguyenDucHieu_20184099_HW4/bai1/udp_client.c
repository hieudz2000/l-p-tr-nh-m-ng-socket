// udp client driver program
#include <stdio.h>
#include <strings.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 1000
static int tmp = 0;

int g = 0;
char buffer[100];
char message[100];
int main(int argc, char *argv[])
{
	// catch wrong input
	if (argc != 3)
	{
		printf("Please input IP address and port number\n");
		return 0;
	}

	char *ip_address = argv[1];
	char *port_number = argv[2];
	int port = atoi(port_number);

	int sockfd, n;
	struct sockaddr_in servaddr;

	// clear servaddr
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_addr.s_addr = inet_addr(ip_address);
	servaddr.sin_port = htons(port);
	servaddr.sin_family = AF_INET;

	// create datagram socket
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sockfd < 0)
	{
		perror("\nError: ");
		return 0;
	}
	int len1;
	do
	{
		printf("INPUT: ");

		g = scanf("%[^\n]", message);
		if (g == 0)
		{
		}

		getchar();

		len1 = sizeof(servaddr);
		int bytes_sent = sendto(sockfd, message, MAXLINE, 0, (struct sockaddr *)&servaddr, sizeof(servaddr));
		if (bytes_sent < 0)
		{
			perror("Error: ");
			close(sockfd);
			return 0;
		}
		char huhu[100];
		int bytes_received;
		bytes_received = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&servaddr, &len1);
		printf("%s\n", buffer);
	} while (1);
	close(sockfd);
	return 0;
}