#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
struct hoc_sinh
{
    char ten[30];
    float diem_gk;
    float diem_ck;
    char diem_chu;
    char ma_sv[20];
    struct hoc_sinh *next;
};
typedef struct hoc_sinh *hs;
struct mon_hoc
{
    char ten[40];
    char ma_hoc_ki[20];
    char ma_mon_hoc[20];
    int so_sv;
    int sv_dang_co;
    
    float sum;
    hs HocSinh;
    struct mon_hoc *next;
};
typedef struct mon_hoc *node;
node head = NULL;
node Create(node value)
{
    node tmp;
    tmp = (node)malloc(sizeof(struct mon_hoc));
    tmp = value;
    tmp->next = NULL;
    return tmp;
}

hs Create_hs(hs value)
{
    hs tmp;
    tmp = (hs)malloc(sizeof(struct hoc_sinh));
    tmp = value;
    tmp->next = NULL;
    return tmp;
}


int in(FILE *a,int x,char*y){
    fprintf(a,"%s%s", y, ":");
    for(int i = 0; i < x; i++){
        fprintf(a,"%s","*");
    }
    fprintf(a,"%s","\n");
    return 0;
}

int chi_tiet(node p){
    char a[40];
    char hk_min[30];
    char hk_max[30];
    strcpy(a,p->ma_mon_hoc);
    strcat(a,"_");
    strcat(a,p->ma_hoc_ki);
    strcat(a,"_rp.txt");
    FILE*fp =fopen(a,"w+");
    hs tmp = p->HocSinh;
    float max = 0;
    float min = 100;
    float k;
    int A = 0,B = 0,C = 0,D= 0, F=0;
    for(tmp = p->HocSinh; tmp != NULL; tmp=tmp->next){
        k = tmp->diem_gk*0.3+tmp->diem_ck*0.7;
        if(tmp->diem_chu == 'A'){
            A++;
        }
        else if(tmp->diem_chu == 'B'){
            B++;
        }
        else if(tmp->diem_chu == 'C'){
            C++;
        }
        else if(tmp->diem_chu == 'D'){
            D++;
        }else F++;
        
        if(max < k ){
            max = k;
            strcpy(hk_max, tmp->ten);

        }
        if(min > k){
            min = k;
            strcpy(hk_min, tmp->ten);
        }
    }
    fprintf(fp,"%s %s\n", "The student with the highest mark is: ", hk_max);
    fprintf(fp,"%s %s\n", "The student with the lowest mark is: ", hk_min);
    fprintf(fp,"%s%.2f\n", "The average mark is: ", p->sum/p->sv_dang_co);
    fprintf(fp,"%s%s%s\n", "A histogram of the subject ",p->ma_mon_hoc," is : ");
    

    in(fp,A,"A");
    in(fp,B,"B");
    in(fp,C,"C");
    in(fp,D,"D");
    in(fp,F,"F");
    fclose(fp);

    
    // fprintf(fp,"%s", "A:");
    // for(int i = 0; i < A; i++){
    //     fprintf(fp,"%s","*");
    // }
    return 0;

}

int thong_tin_mon()
{
    node p = head;
    char a[40];
    strcpy(a,p->ma_mon_hoc);
    strcat(a,"_");
    strcat(a,p->ma_hoc_ki);
    strcat(a, ".txt");
    printf("%s\n", a);
    FILE *fp = fopen(a, "w+");
    fprintf(fp, "%s %s %s\n", "SubjectID","|",p->ma_mon_hoc);
    fprintf(fp, "%s%s%s\n","Subject","|",p->ten);
    fprintf(fp,"%s\n", "F|30|70");
    fprintf(fp,"%s%s\n","Semester|",p->ma_hoc_ki);
    fprintf(fp,"%s%d%s%d\n","StudentCount|",p->sv_dang_co,"/",p->so_sv );
    hs tmp =p->HocSinh;
    for(tmp = p->HocSinh; tmp != NULL; tmp=tmp->next){
        fprintf(fp,"%s %10s %s %15s %s %.2f %s %.2f %s %c\n","S|",tmp->ma_sv,"|",tmp->ten, "|",tmp->diem_gk,"|", tmp->diem_ck,"|",tmp->diem_chu);
    } 
    chi_tiet(p);
    fclose(fp);
    return 0;
}

node add(node value)
{
    node tmp = NULL;
    tmp = value;
    if (head == NULL)
    {
        head = tmp;
       // thong_tin_mon(head);
    }
    else
    {
        node p = head;
        while (p->next != NULL)
        {
            p = p->next;
           // thong_tin_mon(p);
        }
        p->next = tmp;
    }
    return head;
}

hs add_hs(node p, hs value)
{
    hs tmp = NULL;
    // if(p->sv_dang_co == p->so_sv){
    //     printf("lop da day sinh vien roi!!\n");
    //     return NULL;
    // }
    p->sv_dang_co = p->sv_dang_co + 1;
    tmp = value;
    if (p->HocSinh == NULL)
    {
        p->HocSinh = tmp;
    }
    else
    {
        hs a = p->HocSinh;
        while (a->next != NULL)
        {
            a = a->next;
        }
        a->next = tmp;
    }
    return NULL;
    
}
char u[10];


char diem(float a, float b){
    float c = a*0.3+b*0.7;
    if(c < 4){
        return 'F';
    }else if(c < 5.5){
        return 'D';
    }else if(c < 7){
        return 'C';
    }
    else if(c <8.5){
        return 'B';
    }
    else{
        return 'A';
    }
}

int nhap(node p)
{
    printf("nhap ten mon hoc; ");
   
    gets( p->ten);
    printf("nhap ma mon hoc: ");
    
    gets( p->ma_mon_hoc);
    printf("nhap ma hoc ki: ");

    gets( p->ma_hoc_ki);
    printf("nhap so luong sv: ");

    scanf("%d", &p->so_sv);
    gets(u);
    return 0;

}

node case1()
{
    node tmp = NULL;
   
    tmp = (node)malloc(sizeof(struct mon_hoc));
    nhap(tmp);
    add(tmp);
    //free(tmp);
    return NULL;
    // printf("hieudz\n");
    // printf("tmp; %s: \n", tmp->ten);
   // printf("%s\n", head->ten);
}
node search_MaMon_MaHK(char *a, char *b)
{
    node p = head;
   // printf("%s %s \n %s %s\n", p->ma_mon_hoc, p->ma_hoc_ki, a, b);
    if (p == NULL)
    {
        return NULL;
    }
    else
    {
        while (p != NULL)
        {
            if (strcmp(p->ma_mon_hoc, a) == 0 &&strcmp( p->ma_hoc_ki , b) == 0)
            {
                return p;
            }
            p = p->next;
        }
    }
    return NULL;
}

int nhap_hs(hs p){
    printf("nhap ten sv: ");
    int k = 0;
    //gets(p->ten);
    //  scanf("%s", u);
     gets( p->ten);
    printf("nhap ma_sv: ");
   
    gets( p->ma_sv);
    do{
        printf("nhap diem gk va ck (0-10): ");
        scanf("%f%f", &p->diem_gk, &p->diem_ck);
        if(p->diem_gk > 10 || p->diem_gk < 0){
            printf("diem 0-10\nnhap lai \n");
            k = 1;
        }
        else if(p->diem_ck > 10 || p->diem_ck < 0){
             printf("diem 0-10\nnhap lai \n");
             k = 1;
        }else{
            k = 0;
        }
    }while(k == 1);
    
    p->diem_chu = diem(p->diem_gk,p->diem_ck);
    gets(u);

    /////////////////////////// tinh he so a b c d
    return 0;


}

int case2()
{
    char a[20], b[20];
    node p = NULL;
    do
    {
        printf("nhap ma mon hoc: ");
  
        gets( a);
        printf("nhap ma hoc ki: ");
        
        gets( b);
         p = search_MaMon_MaHK(a, b);
        if (p == NULL)
        {
            printf("ko co mon hoc tuong ung\n");
        }
        
    }while(p == NULL);
    hs tmp = NULL;
    tmp = (hs)malloc(sizeof(struct hoc_sinh));
    if(p->sv_dang_co == p->so_sv){
        printf("lop da day sinh vien r !!\n");
        return 0;
    }
    nhap_hs(tmp);
    p->sum = p->sum + tmp->diem_gk*0.3+tmp->diem_ck*0.7;
    add_hs(p, tmp);
    //free(tmp);
    //free(p);
    //printf("so sv: %d\n", p->sv_dang_co);
    // printf("hs: %s\n", p->HocSinh->ten);
    // printf("hs2: %s\n", p->HocSinh->next->ten);
    //hs tmp = Create_hs();
    return 0;

}

hs Search_Mssv(hs tmp, char *a){
    hs p = tmp;
    if(strcmp(p->ma_sv, a) == 0){
        tmp = tmp->next;
        return tmp;
    }

    while(p != NULL){
        if(strcmp(p->next->ma_sv, a) == 0){
            if(p->next->next == NULL){
                free(p->next);
                p->next = NULL;
                return tmp;
            }
            else{
                hs t = p->next;
                p->next = p->next->next;
                free(t);
                return tmp;
            }
        }
        p = p->next;
    }
    return NULL;
}

hs Seach_hs_MSSV(hs tmp, char *a){
     hs p = tmp;
    

    while(p != NULL){
        if(strcmp(p->ma_sv, a) == 0){
            
            return p;
        }
        p = p->next;
    }
    return NULL;
}

int case3(){
    char a[20], b[20], c[20];
    node p = NULL;
    hs p1 = NULL;
    do{
        printf("nhap ma mon hoc: ");
       
        gets( a);
        printf("nhap ma hoc ki: ");
         gets( b);
       
        printf("nhap ma sv muon xoa: ");
      
        gets( c);
        p = search_MaMon_MaHK(a, b);
        if(p == NULL){
            printf("ko ton tai mon hoc va hoc ki nay\n");
        }else{
           
            p1 = Search_Mssv(p->HocSinh,c);
            if(p1 == NULL){
                printf("ko co sinh vien trong lop hoc\n");
            }
            else{
                 p->sv_dang_co = p->sv_dang_co -1;
                hs p2;
                for(p2 = p1; p2 != NULL; p2=p2->next){
                    printf("%s\n",p2->ten);
                }
            }
        }
    }while(p == NULL || p1 == NULL);
    return 0;

}


int menu()
{
    printf("Learning Management System\n");
    printf("-------------------------------------\n");
    printf("1. Add a new score board\n");
    printf("2. Add score\n");
    printf("3. Remove score\n");
    printf("4. Search score\n");
    printf("5. Display score board and score report\n");
    printf("Your choice (1-5, other to quit):\n");
    return 0;

}

int case4(){
    node p;
    hs p1;
    char a[20], b[20], c[20];
    do{
        printf("nhap ma mon hoc: ");
         gets( a);
       
        printf("nhap ma hoc ki: ");
         gets( b);
      
        printf("nhap ma sv muon tra: ");
         gets( c);
        
        p = search_MaMon_MaHK(a, b);
        if(p == NULL){
            printf("ko ton tai mon hoc va hoc ki nay\n");
        }else{
            p1 =  Seach_hs_MSSV(p->HocSinh,c);
            if(p1 == NULL){
                printf("ko co sinh vien trong lop hoc\n");
            }
            else{
                printf("thong tin sinh vien: %s\n", p1->ten);
                printf("diem gk: %f\ndiem ck: %f\n", p1->diem_gk, p1->diem_ck);
            }
        }
    }while(p == NULL||p1 == NULL);
    return 0;

}

int printf_diem(hs p){
    printf("|------------------------------------------------------|    \n");
    printf("| ho va ten   | MSSV    | diem gk |  diem ck| diem chu |\n");
    printf("|------------------------------------------------------|    \n");
    hs tmp;
    for(tmp = p; tmp != NULL; tmp = tmp->next){
        printf("|%13s|%9s|%9.2f|%9.2f|%10c|\n", tmp->ten, tmp->ma_sv,tmp->diem_gk, tmp->diem_ck, tmp->diem_chu);
           printf("|------------------------------------------------------|    \n");

    }
    return 0;


}

int case5(){
    node p;
    
    char a[20], b[20];
    do{
        printf("nhap ma mon hoc: ");
         gets( a);
       
        printf("nhap ma hoc ki: ");
         gets( b);
       
        
        p = search_MaMon_MaHK(a, b);
        if(p == NULL){
            printf("ko ton tai mon hoc va hoc ki nay\n");
        }else{
            printf_diem(p->HocSinh);
        }
    }while(p == NULL);
    return 0;

}
int free_node(){
   node k = head;
    hs t;
    while(head != NULL){
        while (head->HocSinh != NULL){
            t = head->HocSinh;
            head->HocSinh=head->HocSinh->next;
            free(t);
        }
        
        k = head;
        head = head->next;
        free(k);
    }
   
}

int main()
{
    int n;
    char m[2];
    do
    {
        menu();
        printf("moi chon: ");
        scanf("%d", &n);
    gets(u);

        switch (n)
        {
        case 1:
            case1();
            
            do{
            
            printf("ban muon su dung tiep chuc nang nay ko? (y/n)");
            gets(m);
          
            if(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0){
                case1();
            }

            }while(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0);
            break;
        case 2:
            case2();
            do{
            
            printf("ban muon su dung tiep chuc nang nay ko? (y/n)");
            gets(m);
          
            if(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0){
                case2();
            }

            }while(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0);
            break;
        case 3:
            case3();
            do{
            
            printf("ban muon su dung tiep chuc nang nay ko? (y/n)");
            gets(m);
          
            if(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0){
                case3();
            }

            }while(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0);
        case 4:
            case4();
            do{
            
            printf("ban muon su dung tiep chuc nang nay ko? (y/n)");
            gets(m);
          
            if(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0){
                case4();
            }

            }while(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0);
            break;
        case 5:
            case5();
            do{
            
            printf("ban muon su dung tiep chuc nang nay ko? (y/n)");
            gets(m);
          
            if(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0){
                case5();
            }

            }while(strcmp(m, "y") == 0 || strcmp(m, "Y") == 0);
            break;
        }
    } while (n >= 1 && n <= 5);
    thong_tin_mon();
    free_node();
    
    
    return 0;

}