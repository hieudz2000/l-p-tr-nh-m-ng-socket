//
// Created by hainguyen on 01/01/2022.
//


#ifndef LTM_PROJECT_HANDLERECVDATA_H
#define LTM_PROJECT_HANDLERECVDATA_H


#include "structScreen.h"

void handleRecvData(char *dataRecv, UserData *userData);

#endif //LTM_PROJECT_HANDLERECVDATA_H
