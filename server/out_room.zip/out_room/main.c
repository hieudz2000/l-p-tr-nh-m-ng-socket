#include <stdio.h> /* These are the usual header files */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include "data.c"

#define PORT 5506  /* Port that will be opened */
#define BACKLOG 20 /* Number of allowed connections */
#define BUFF_SIZE 1024

ServerData serverData;
struct cauhoi
{
	char ques[100];
	char dapan[100];
	int lv;
};

struct cauhoi ch[100];

int cau_hoi(MYSQL *con)
{
	printf("vao day r\n");
	if (mysql_real_connect(con, "localhost", "root", "Pass1234@", "login", 0, NULL, 0) == NULL)
	{
		finish_with_error(con);
	}
	if (mysql_query(con, "SELECT * FROM cauhoi"))
	{
		finish_with_error(con);
	}
	MYSQL_RES *result = mysql_store_result(con);

	if (result == NULL)
	{
		finish_with_error(con);
	}

	int num_fields = mysql_num_fields(result);

	MYSQL_ROW row;
	int k = 0;

	while ((row = mysql_fetch_row(result)))
	{
		for (int i = 0; i < num_fields; i++)
		{
			strcpy(ch[k].ques, row[1]);
			strcpy(ch[k].dapan, row[2]);
			ch[k].lv = atoi(row[3]);
			//printf("%s ", row[i] ? row[i] : "NULL");
		}
		k++;
	}
	return 0;
}
int cauhoi1()
{
	MYSQL *con1 = mysql_init(NULL);
	cau_hoi(con1);
	int lv1 = 0, lv2 = 0;

	for (int i = 0; i < 8; i++)
	{
		//	printf("%s\n", ch[i].ques);

		if (ch[i].lv == 1)
		{
			strcpy(room[lv1].hoi_1, ch[i].ques);
			strcpy(room[lv1].dapan_1, ch[i].dapan);
			lv1++;
		}
		else if (ch[i].lv == 2)
		{
			strcpy(room[lv2].hoi_2, ch[i].ques);
			strcpy(room[lv2].dapan_2, ch[i].dapan);
			lv2++;
		}
	}
}

int main()
{
	ssize_t t;
	pthread_t rom1;
	cauhoi1();
	for (int i = 0; i < 4; i++)
	{
		printf("%s %s\n", room[i].hoi_1, room[i].dapan_1);
	}
	int ret = pthread_create(&rom1, NULL, multiModeHandleNewGame, &room[0]);
	int ret1 = pthread_create(&rom1, NULL, multiModeHandleNewGame, &room[1]);
	int ret2 = pthread_create(&rom1, NULL, multiModeHandleNewGame, &room[2]);
	int ret3 = pthread_create(&rom1, NULL, multiModeHandleNewGame, &room[3]);
	//pthread_t rom1, rom2, rom3, rom4;

	struct timeval timeout;
	timeout.tv_sec = 5; // Server sẽ lắng nghe trong 90s, nếu tham số timeout = NULL thì select sẽ chạy mãi.
	timeout.tv_usec = 0;
	if (initServer(&serverData, PORT))
	{
		printf("Can't create socket!\n");
		return -1;
	}

	while (1)
	{
		sleep(2);
		updateNewReadFds(&serverData);
		int selectStatus = select(serverData.maxFd, &(serverData.readFds), NULL, NULL, &timeout);
		if (selectStatus == -1)
		{
			printf("Close server :\n");
			break;
		}
		else if (selectStatus == 0)
		{
			printf("CAP NHAT LAI !\n");
		}
		else
		{
			handleSelect(&serverData);
		}
	}
}
// bi loi out het thi ko random lai dc
