//
// Created by dung on 18/01/2022.
//

#ifndef LTM_PROJECT_WINNERCONTROLLER_H
#define LTM_PROJECT_WINNERCONTROLLER_H
#include "structScreen.h"
#include "handleMain.h"

void winner_back_home(GtkButton *button,UserData *userData);
#endif //LTM_PROJECT_WINNERCONTROLLER_H
