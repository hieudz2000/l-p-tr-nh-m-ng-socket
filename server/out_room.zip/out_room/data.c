#include <stdio.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "xuli.c"
#include <string.h>
#include <mysql/mysql.h>
#include "mysql.c"
#define MAX_LEN_BUFF 1024

struct play
{
    int diem;
    char id[10];
    char name[20];
    char pass[20];
    int socfd;
    int online; // = 1 lắng nghe trong room, =0 lắng nghe từ server
    struct sockaddr_in clientAddr;
};

typedef struct play client;
client reset_client;

int mm = 0;
struct rooms
{
    char hoi_1[100];
    char hoi_2[100];
    char dapan_1[100];
    char dapan_2[100];
    int count;
    int id_room;
    int on; // room co ton tai hay ko
    client Client[3];
};

typedef struct rooms rooms;
//////////////////////////////

typedef struct
{
    client client[10];

    struct sockaddr_in serverAddr;
    int listenFD;
    fd_set readFds;
    int maxFd;
    int count; // số client
    int so_room;
} ServerData;

ServerData server;

int tim_kiem(int socfd, ServerData *server)
{
    int k = server->count;
    for (int i = 0; i <= k; i++)
    {
        if (socfd == server->client[i].socfd)
        {
            return i;
        }
    }
}

struct rooms room[100];

int xet_room(rooms *room, int socfd)
{ // xets lai vi tri va update data, xoa ra khoi room

    //serverData.client[h].online = 0;
    int n = -1;
    for (int i = 0; i < room->count; i++)
    {
        if (room->Client[i].socfd == socfd)
        {
            n = i;
            break;
        }
    }
    if (n == -1)
    {
        printf("ko co client day trong room\n");
    }
    char data_send[100];
    char data[100];
    // int h = tim_kiem(room->Client[n].socfd,);
    printf("count: %d\n", room->count);
    if (room->count == 1)
    {
        // sprintf(data, data_send, room->count - 1, n);
        // send(room->Client[n].socfd, data_send, 1024, 0); // so ng trong phong la 1 thi se thoat phong
        room->on = 0; // phong chua dc tao
        room->count = 0;
        room->Client[n] = reset_client;
    }
    //player_out_room#1#vi tri
    else if (room->count == 2)
    {
        sprintf(data, "player_out_room#%d#%d", room->count - 1, n + 1);
        if (n == 1)
        {
            room->Client[n] = reset_client;
            if (send(room->Client[0].socfd, data, 1024, 0) < 0)
            {
                printf("ko gui dc out room khi co 2 ng\n");
            }
            else
            {
                printf("send out room 2 nguoi(2): %s\n", data);
            }
        }
        else if (n == 0)
        {
            if (send(room->Client[1].socfd, data, 1024, 0) < 0)
            {
                printf("ko gui dc out room khi co 2 ng\n");
            }
            else
            {
                printf("send out room khi co 2 nguoi (1): %s\n", data);
            }
            room->Client[0] = room->Client[1];
            room->Client[1] = reset_client;
        }
        room->count--;
    }
    // else if (room->count == 3)
    // {
    //     sprintf(data, "player_out_room#%d#%d", room->count - 1, n + 1);
    //     for (int i = 0; i < room->count; i++)
    //     {
    //         if (room->Client[i].socfd == socfd)
    //         {
    //             continue;
    //         }
    //         else
    //         {
    //             if (send(room->Client[i].socfd, data, 1024, 0) < 0)
    //             {
    //                 printf("ko gui dc 3 dua\n");
    //             }
    //             else
    //             {
    //                 printf("out_room 3 dua : %s\n", data);
    //             }
    //         }
    //     }
    //     if (n == 1)
    //     {
    //         room->Client[1] = room->Client[2];
    //         room->Client[2] = reset_client;
    //     }
    //     else if (n == 0)
    //     {
    //         room->Client[0] = room->Client[1];
    //         room->Client[1] = room->Client[2];
    //         room->Client[2] = reset_client;
    //     }
    //     room->count--;
    // }
}

void *multiModeHandleNewGame(void *argv)
{
    rooms *game = (rooms *)argv;
    int soc[3], m;
    fd_set readFds;
    char recvdata[100];
    int maxFd = 0, selectStatus;
    int k = 0;
    int tmp = 0;
    while (1)
    {
        sleep(2);
        if (game->count == 2)
        {

            for (int i = 0; i < game->count; i++)
            {
                if (game->Client[i].online == 0 || game->Client[i].online == -1)
                {
                    tmp = 1;
                    break;
                }
                soc[i] = game->Client[i].socfd;
                maxFd = maxFd > soc[i] ? maxFd : soc[i];
            }
            if (tmp == 1)
            {
                tmp = 0;
                maxFd = 0;
            }
            else
            {
                printf("\t\t\t vao ham khi du 2 ng chs\n\n");
                FD_ZERO(&readFds);
                for (int i = 0; i < 2; i++)
                {
                    FD_SET(soc[i], &readFds);
                }
                selectStatus = select(maxFd + 1, &readFds, NULL, NULL, NULL);

                if (selectStatus == -1)
                {
                    printf("Break thread :\n");
                    pthread_exit(NULL);
                }
                else if (selectStatus == 0)
                {
                    printf("Het thoi gian cho!\n");
                    printf("Break thread :\n");
                    pthread_exit(NULL);
                }
                else
                {

                    if (FD_ISSET(soc[0], &readFds))
                    {
                        memset(recvdata, '\0', 1024);
                        m = recv(soc[0], recvdata, 1024, 0);
                        recvdata[m] = '\0';
                        printf("ng 1 nhan: %s\n", recvdata);
                        tim_diem(recvdata, &game->Client[0].diem);
                        printf("nhan: %s\tdiem:%d\n", recvdata, game->Client[0].diem);
                        if (strstr(recvdata, "end_round") != NULL && m > 0)
                        {
                            printf("end game thoi ae oi cua thanfwf 1\n");
                            int first = xet_diem(game->Client[0].diem, game->Client[1].diem, 0);
                            char aa[300];
                            sprintf(aa, "#%d#%s#%s", first, game->hoi_2, game->dapan_2);
                            strcat(recvdata, aa);
                            //send_cuoi(recvdata, "2");
                            if (send(soc[0], recvdata, 1024, 0) < 0 || send(soc[1], recvdata, 1024, 0) < 0)
                            {
                                printf("ko gui dc end_round 1\n");
                            }
                            else
                            {
                                printf("data send end round 1: %s\n", recvdata);
                            }
                            printf("room truoc: %d\n", ((rooms *)argv)->Client[0].online);
                            printf("room onlien: %d\t%d\t%d\n", game->on, ((rooms *)argv)->on, room[0].on);

                            // out room
                            game->Client[0].online = -1;
                            game->Client[1].online = -1;
                            printf("room sau: %d\n", ((rooms *)argv)->Client[0].online);
                            // room-.on = 1
                            // room->Client[2].online = 0;

                            printf("loi thoat room thang 1\n");

                            //pthread_exit(NULL);
                        }
                        else
                        {

                            strcat(recvdata, "#2");
                            printf("doc thang 1: %s\n", recvdata);
                            send(soc[1], recvdata, 1024, 0);
                            //send(soc[2], recvdata, 1024, 0);
                            send(soc[0], recvdata, 1024, 0);
                        }
                    }
                    if (FD_ISSET(soc[1], &readFds))
                    {
                        memset(recvdata, '\0', 1024);
                        m = recv(soc[1], recvdata, 1024, 0);
                        recvdata[m] = '\0';
                        tim_diem(recvdata, &game->Client[1].diem);

                        printf("ng 2 nhan: %s\n", recvdata);
                        tim_diem(recvdata, &game->Client[1].diem);
                        if (strstr(recvdata, "end_round") != NULL && m > 0)
                        {
                            printf("end game thoi ae oi cua thanfwf 2\n");
                            int first = xet_diem(game->Client[0].diem, game->Client[1].diem, 0);
                            char aa[300];
                            sprintf(aa, "#%d#%s#%s", first, game->hoi_2, game->dapan_2);

                            strcat(recvdata, aa);
                            //send_cuoi(recvdata, "1");

                            if (send(soc[0], recvdata, 1024, 0) < 0 || send(soc[1], recvdata, 1024, 0) < 0)
                            {
                                printf("ko gui dc end_round 2\n");
                            }
                            else
                            {
                                printf("data send end round2: %s\n", recvdata);
                            }

                            // out room
                            printf("room onlien: %d\t%d\t%d\n", game->on, ((rooms *)argv)->on, room[0].on);
                            printf("room truoc: %d\n", ((rooms *)argv)->Client[0].online);
                            game->Client[0].online = -1;
                            game->Client[1].online = -1;
                            printf("room sau: %d\n", ((rooms *)argv)->Client[0].online);
                            // room->Client[2].online = 0;
                            printf("loi thoat room thang 2\n");
                            // pthread_exit(NULL);
                        }
                        else
                        {
                            strcat(recvdata, "#1");
                            printf("doc thang 2: %s\n", recvdata);
                            send(soc[0], recvdata, 1024, 0);
                            //  send(soc[2], recvdata, 1024, 0);
                            send(soc[1], recvdata, 1024, 0);
                        }
                    }
                }
            }
        }
    }
}

/////// 3 thang , khi nao 1 th an nut start-> server : gan lai cho client.online = 0, 1 client : server : client = 1,

int initServer(ServerData *serverData, int port)
{
    bzero(&serverData->serverAddr, sizeof(serverData->serverAddr));
    serverData->serverAddr.sin_family = AF_INET;
    serverData->serverAddr.sin_port = htons(port);
    serverData->serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serverData->listenFD = socket(AF_INET, SOCK_STREAM, 0);
    if (serverData->listenFD == -1)
    {
        perror("\nserver Error: ");
        return 0;
    }
    else
    {
        printf("tao thanh con server\n");
    }

    bind(serverData->listenFD, (struct sockaddr *)&(serverData->serverAddr), sizeof(serverData->serverAddr));
    listen(serverData->listenFD, 10);
    serverData->maxFd = serverData->listenFD + 1;
    return 0;
}

void updateNewReadFds(ServerData *serverData)
{
    //  printf("upsata: maxFD: %d\nlisentFD: %d\n", serverData->maxFd, serverData->listenFD);
    //  printf("\t\tUPDATE\n");
    int maxFd = serverData->listenFD;
    int tmpSockFd, k;
    FD_ZERO(&(serverData->readFds));
    FD_SET(serverData->listenFD, &(serverData->readFds));
    //printf("count %d\n", serverData->count);
    int mm;
    /// kiem tra xem co phong nao vua chs xong ko de gan lai, vi khi chs xong van de room.on = 1, chi gan lai client.online = 0
    for (int i = 0; i < serverData->so_room; i++)
    {
        // printf("id room : %d\t on: %d\t client[0]: %d\n", room[i].id_room, room[i].on, room[i].Client[0].online);
        if (room[i].count == 2 && room[i].on == 1 && room[i].Client[0].online == -1) // 1 1 0      2    1
        {
            printf("reset lai room %d\n", i);
            room[i].on = 2;
            for (int j = 0; j < 2; j++)
            {
                mm = tim_kiem(room[i].Client[j].socfd, serverData);
                serverData->client[mm].online = 0;
            }
        }
    }

    //
    for (int i = 0; i < serverData->count; i++) // bo dau = thi loi
    {
        // printf("hie\n");
        if (serverData->client[i].online == 1)
        {
            continue;
        }
        tmpSockFd = serverData->client[i].socfd;
        FD_SET(tmpSockFd, &(serverData->readFds));
        maxFd = maxFd > tmpSockFd ? maxFd : tmpSockFd;
    }
    // printf("\t\tOUT UPDATE\n");
    serverData->maxFd = maxFd + 1;
}

void handleAcceptConnect(ServerData *serverData)
{

    int cnnFd;
    struct sockaddr_in clientAddr;
    socklen_t sockAddrLen;
    memset(&clientAddr, 0, sizeof clientAddr);
    cnnFd = accept(serverData->listenFD, (struct sockaddr *)&clientAddr, &sockAddrLen);
    printf("You got a connection from %s\n", inet_ntoa(clientAddr.sin_addr)); /* prints client's IP */
    int k = serverData->count;
    serverData->client[k].socfd = cnnFd;
    serverData->client[k].clientAddr = clientAddr;
    serverData->count++;
    if (serverData->maxFd < cnnFd)
    {
        serverData->maxFd = cnnFd;
        serverData->maxFd++;
    }
    FD_SET(cnnFd, &(serverData->readFds));
}

void handleRecvData(int sockFd, ServerData *serverData)
{
    MYSQL *con = mysql_init(NULL);
    int vitri = tim_kiem(sockFd, serverData);
    char recvData[MAX_LEN_BUFF], tmp[MAX_LEN_BUFF];
    int recvSize;
    recvSize = recv(sockFd, recvData, MAX_LEN_BUFF, 0);
    recvData[recvSize] = '\0';
    printf("clienr gui: %s\n", recvData);
    strcpy(tmp, recvData);
    char *token = strtok(tmp, "#");
    ///////
    printf("token: %s\n", token);
    if (strcmp(token, "login") == 0)
    { // kiem tra xem tk vs ml co chinh xac ko, neu dung thi cp id vao socket client de cap nhat
        int m;
        printf("\t\t\tvao dc login\n\n");
        char user[100], pass[100], id[5];
        char sucess[100] = "login_success#";
        xuli(recvData, user, pass);
        if (check_sign_in(con, user, pass, id) == 1)
        {

            m = tim_kiem(sockFd, serverData);
            strcpy(serverData->client[m].id, "1");
            strcpy(serverData->client[m].name, user);
            strcpy(serverData->client[m].pass, pass);
            printf("dang nhap thanh cong ^^\n");
            strcat(sucess, "1");
            send(sockFd, sucess, 1024, 0);
            printf("\t\t\thet login\n\n");
        }
        else
        {
            printf("dang nhap that bai\n");
            send(sockFd, "login_fail#dang nhap that bai", 1024, 0);
        }
    }
    else if (strcmp(token, "register") == 0)
    {
        char user[100], pass[100], id[5];
        char success[101] = "register_success";
        xuli(recvData, user, pass);
        printf("user:%s\n", user);
        printf("pass:%s\n", pass);
        if (check_sign_up(con, user) == 1)
        {
            MYSQL *con1 = mysql_init(NULL);
            printf("dang nhap dc\n");
            insert_data(con1, user, pass);

            printf("dang ki thanh cong ^^\n");
            // strcat(success, id);
            send(sockFd, success, 1024, 0);
        }
        else
        {
            printf("dang ki that bai\n");
            send(sockFd, "register_fail#ten tai khoan da ton tai", 1024, 0);
        }
    }
    else if (strcmp(token, "create_room") == 0)
    {
        printf("\t\t\tvao create\n\n");
        // pthread_t rom1;
        int m = serverData->so_room;
        serverData->so_room++;
        // serverData->client[vitri].online = 1; // no ko lang nghe luong cua su kien chinh nua
        room[m].id_room = m;
        room[m].on = 1; // phong da dc tao
        int n = room[m].count;
        room[m].count++;
        int k = tim_kiem(sockFd, serverData);
        //room[m].Client[n].online = 0; // client trong phong
        strcpy(room[m].Client[n].id, serverData->client[k].id);
        strcpy(room[m].Client[n].name, serverData->client[k].name);
        room[m].Client[n].socfd = sockFd;
        char a[300];
        sprintf(a, "create_room_success#%d#%s#%s", m, room[m].hoi_1, room[m].dapan_1);
        // printf("so ng trong phong hien tai la: %d\n", n);
        // printf("ng chs %s dang o trong phong so %d\n", room[m].Client[n].name, room[m].id_room);
        send(sockFd, a, 1024, 0);
        printf("data send: %s\n", a);
        printf("\t\t\tcreate thanh cong\n\n");
        // int ret = pthread_create(&rom1, NULL, multiModeHandleNewGame, &room[m]);
    }
    else if (strcmp(token, "join_random_room") == 0)
    {
        printf("\t\t\tvao join random room\n\n");
        int k = serverData->so_room;
        int i, count_client;
        // tim phong con trong
        for (i = 0; i < k; i++)
        {
            if (room[i].count < 2 && room[i].on == 1)
            {
                break;
            }
        }
        if (i == k)
        {
            send(sockFd, "join_random_room_fail#khong con phong nao trong", 1024, 0);
        }
        else
        {
            // serverData->client[vitri].online = 1;
            count_client = room[i].count;
            room[i].count++;
            // tim thong tin cua thang nay
            int h = tim_kiem(sockFd, serverData);
            // them thang nay vao phong
            room[i].Client[count_client].socfd = sockFd;
            //room[i].Client[count_client].online = 1;

            strcpy(room[i].Client[count_client].id, serverData->client[h].id);
            strcpy(room[i].Client[count_client].name, serverData->client[h].name);
            char a[100] = "join_random_room_success#%d#%d"; //mde
            char b[100], data[10][100];
            char new[100] = "new_player_join_room#%d#%s";
            char new_play[100];
            sprintf(new_play, new, count_client, room[i].Client[count_client].name);
            sprintf(b, a, i, count_client);
            for (int j = 0; j < count_client; j++)
            {
                strcat(b, "#");
                strcat(b, room[i].Client[j].name);

                send(room[i].Client[j].socfd, new_play, 1024, 0);
            }
            char mm[300];
            sprintf(mm, "#%s#%s", room[i].hoi_1, room[i].dapan_1);
            strcat(b, mm);
            send(sockFd, b, 1024, 0);
            printf("data send: %s\n", b);
            printf("\t\t\trandom thanh cong\n\n");

            if (count_client == 1)
            {
                for (int j = 0; j < room[i].count; j++)
                {

                    send(room[i].Client[j].socfd, "can_start_game#1", 1024, 0);
                }
            }
        }
    }

    else if (strcmp(token, "join_room") == 0)
    {
        printf("\t\t\tjoin room id\n\n");
        int i;
        char id_room[10], u[10];
        xuli(recvData, id_room, u);
        int id = atoi(id_room);
        for (i = 0; i < serverData->so_room; i++)
        {
            if (id == room[i].id_room)
            {
                break;
            }
        }
        if (i == serverData->so_room || room[i].count == 2 || room[i].on == 0)
        {
            send(sockFd, "join_room_fail#phongquanguoi/khongtontai", 1024, 0);
        }
        else
        {
            //serverData->client[vitri].online = 1;
            int count_client = room[i].count;
            room[i].count++;
            // tim thong tin cua thang nay
            int h = tim_kiem(sockFd, serverData);
            // them thang nay vao phong
            room[i].Client[count_client].socfd = sockFd;
            //room[i].Client[count_client].online = 1;
            strcpy(room[i].Client[count_client].id, serverData->client[h].id);
            strcpy(room[i].Client[count_client].name, serverData->client[h].name);
            //join_room_success#id cua room vua vao# so thang dang trong room(1/2)#ten cua thang 1#ten cua thang 2 (nho gui dung thu tu)
            char a[100] = "join_room_success#%d#%d"; // cau hoi#dap an
            char b[100];
            //gui cho các bọn trong phòng
            char new[100] = "new_player_join_room#%d#%s";
            char new_play[100];
            sprintf(new_play, new, count_client, room[i].Client[count_client].name);
            sprintf(b, a, i, count_client);
            for (int j = 0; j < count_client; j++)
            {
                strcat(b, "#");
                printf("%s\t", room[i].Client[j].name);
                strcat(b, room[i].Client[j].name);
                send(room[i].Client[j].socfd, new_play, 1024, 0);
            }
            char mm[300];
            sprintf(mm, "#%s#%s", room[i].hoi_1, room[i].dapan_1);
            strcat(b, mm);
            send(sockFd, b, 1024, 0);
            printf("data send :\n%s\n", b);
            printf("\t\t\tjoin room id thanh cong\n\n");

            if (count_client == 1)
            {
                // char cauhoi[100], dapan[100];

                // char aa[100] = "can_start_game#linamde#ai la vua#1";
                // char bb[100];

                for (int j = 0; j < room[i].count; j++)
                {
                    send(room[i].Client[j].socfd, "can_start_game#1", 1024, 0);
                }
                //send(sockFd, aa, 1024, 0);
            }
        }
    }
    else if (strcmp(token, "out_room") == 0)
    {

        printf("\t\t\tvao out room :\n\n");
        token = strtok(NULL, "#");
        printf("out room %s\n", token);
        /// gan lai vi tri zoom
        int zoom_id = atoi(token);
        printf("room id : %d\n", zoom_id);
        xet_room(&room[zoom_id], sockFd);
    }
    else if (strcmp(token, "start_game") == 0)
    {
        int san_sang = 0;
        printf("\t\t\tstart game\n\n");
        token = strtok(NULL, "#");
        int id_room = atoi(token);
        serverData->client[vitri].online = 1;
        printf("start: %d\n", room[id_room].count);
        printf("so ng san sang:\n");
        for (int i = 0; i < room[id_room].count; i++)
        {
            if (room[id_room].Client[i].socfd == sockFd)
            {
                room[id_room].Client[i].online = 1;
            }
            printf("%s:'%d'\n", room[id_room].Client[i].name, room[id_room].Client[i].online);

            // ko nhan lenh cua cha nua
        }
        // kiem tra xem trong zoom ay 3 th online het chua

        char cauhoi[100], dapan[100];

        char aa[100] = "start_game";
        char bb[100];

        for (int j = 0; j < 2; j++)
        {
            if (send(room[id_room].Client[j].socfd, aa, 1024, 0) < 0)
            {
                printf("ko the start game\n");
            }
            else
            {
                printf("data send: %s\n", aa);
            }
        }
        //send(sockFd, aa, 1024, 0);

        printf("\t\t\tstart thanh cong\n\n");
    }
}

void handleSelect(ServerData *serverData)
{
    //   printf("handSElect\tmaxFD: %d\tlisentFD: %d\n", serverData->maxFd, serverData->listenFD);
    for (int i = 0; i < serverData->maxFd; i++)
    {
        if (FD_ISSET(i, &(serverData->readFds)))
        {
            if (i == serverData->listenFD)
            {
                //  printf("\nmmm\n");
                handleAcceptConnect(serverData);
            }
            else
            {
                handleRecvData(i, serverData);
            }
        }
    }
}

/// khi createm ,join, random thi ko gan online = 1 nen trong thread room no ko lang nghe , no van xu li su kien cua luong chinh

/// khi ma an start thi gan tat ca client trong romm : online = 1;
// gcc -pthread -o server main.c `mysql_config --cflags --libs`