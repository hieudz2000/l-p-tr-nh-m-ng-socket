#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <fcntl.h>	// for open
#include <unistd.h> // for close
#include <pthread.h>
#include <stdlib.h>
#define PORT 5500  /* Port that will be opened */
#define BACKLOG 20 /* Number of allowed connections */
#define BUFF_SIZE 1024
char buff[BUFF_SIZE + 1];
/* Receive and echo message to client */
void *echo(void *);
int xuli();
int tmp = 0;
int main()
{

	int listenfd, *connfd;
	struct sockaddr_in server;	/* server's address information */
	struct sockaddr_in *client; /* client's address information */
	int sin_size;
	pthread_t tid;
	if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{ /* calls socket() */
		perror("\nError: ");
		return 0;
	}
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(PORT);
	server.sin_addr.s_addr = htonl(INADDR_ANY); /* INADDR_ANY puts your IP address automatically */
	if (bind(listenfd, (struct sockaddr *)&server, sizeof(server)) == -1)
	{
		perror("\nError: ");
		return 0;
	}

	if (listen(listenfd, BACKLOG) == -1)
	{
		perror("\nError: ");
		return 0;
	}

	sin_size = sizeof(struct sockaddr_in);
	client = malloc(sin_size);
	while (tmp == 0)
	{
		connfd = malloc(sizeof(int));
		if ((*connfd = accept(listenfd, (struct sockaddr *)client, &sin_size)) == -1)
			perror("\nError: ");
		printf(" client1:  [%s:%d]: \n", inet_ntoa(client->sin_addr), ntohs(client->sin_port));
		//printf("You got a connection from %s\n", inet_ntoa(client->sin_addr)); /* prints client's IP */
		pthread_create(&tid, NULL, &echo, (void *)connfd);
	}

	close(listenfd);
	return 0;
}

static int k = 0;

int xuli()
{

	if (strcmp(buff, "q") == 0 || strcmp(buff, "Q") == 0)
	{
		exit(0);
		return 0;
	}

	for (int i = 0; i < strlen(buff); i++)
	{
		if (buff[i] < 'A' || buff[i] > 'z')
		{
			return 2;
		}
		else if (buff[i] > 'Z' && buff[i] < 'a')
		{
			return 2;
		}
		else
		{
			if (buff[i] >= 'a' && buff[i] <= 'z')
			{
				buff[i] -= 32;
			}
		}
	}
	return 1;
}
int byte;
void *echo(void *arg)
{
	k++;
	printf("co %d client ket noi\n", k);
	char mes[100] = "Wrong text format";
	int connfd;
	int bytes_sent, bytes_received;

	connfd = *((int *)arg);
	free(arg);
	//pthread_detach(pthread_self());
	// bytes_received = recv(connfd, buff, BUFF_SIZE, 0);
	// printf("%s\n", buff);
	while (tmp == 0)
	{
		memset(buff, '\0', (strlen(buff) + 1));
		bytes_received = recv(connfd, buff, BUFF_SIZE, 0);
		byte += bytes_received;
		if (strcmp(buff, "q") == 0 || strcmp(buff, "Q") == 0)
		{
			close(connfd);
			break;
		}
		int m = xuli();

		if (m == 0)
		{
			close(connfd);
			break;
		}
		if (m == 2)
		{
			bytes_sent = send(connfd, mes, strlen(mes), 0);
		}
		else if (m == 1)
		{
			bytes_sent = send(connfd, buff, strlen(buff), 0);
		}
	}
	close(connfd);
}
