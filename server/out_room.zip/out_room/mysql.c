#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char lv1[10][100];
char lv2[10][100];

struct ngs_chs_da_dang_nhap
{
    char name[100];
};
char tmp = 0;
struct ngs_chs_da_dang_nhap user_da_dang_nhap[100];

void finish_with_error(MYSQL *con)
{
    fprintf(stderr, "%s\n", mysql_error(con));
    mysql_close(con);
    exit(1);
}

int check_sign_in(MYSQL *con, char *user, char *pass, char *id)

{
    for (int i = 0; i < tmp; i++)
    {

        if (strcmp(user_da_dang_nhap[i].name, user) == 0)
        {
            return 0;
        }
    }
    if (mysql_real_connect(con, "localhost", "root", "Pass1234@", "login", 0, NULL, 0) == NULL)
    {
        finish_with_error(con);
    }
    if (mysql_query(con, "SELECT * FROM user"))
    {
        finish_with_error(con);
    }
    MYSQL_RES *result = mysql_store_result(con);

    if (result == NULL)
    {
        finish_with_error(con);
    }

    int num_fields = mysql_num_fields(result);

    MYSQL_ROW row;

    while ((row = mysql_fetch_row(result)))
    {
        for (int i = 0; i < num_fields; i++)
        {
            if (strcmp(user, row[1]) == 0)
            {
                if (strcmp(pass, row[2]) == 0)
                {
                    strcpy(user_da_dang_nhap[tmp].name, row[1]);
                    tmp++;
                    strcpy(id, row[0]);
                    return 1;
                }
            }
            //printf("%s ", row[i] ? row[i] : "NULL");
        }
    }
    return 0;
}

int check_sign_up(MYSQL *con, char *user)
{
    if (mysql_real_connect(con, "localhost", "root", "Pass1234@", "login", 0, NULL, 0) == NULL)
    {
        finish_with_error(con);
    }
    if (mysql_query(con, "SELECT * FROM user"))
    {
        finish_with_error(con);
    }
    MYSQL_RES *result = mysql_store_result(con);

    if (result == NULL)
    {
        finish_with_error(con);
    }

    int num_fields = mysql_num_fields(result);

    MYSQL_ROW row;

    while ((row = mysql_fetch_row(result)))
    {
        for (int i = 0; i < num_fields; i++)
        {
            if (strcmp(user, row[1]) == 0)
            {
                return 0;
            }
            //printf("%s ", row[i] ? row[i] : "NULL");
        }
    }
    return 1;
}

int insert_data(MYSQL *con, char *user, char *pass)
{
    // strcpy(user_da_dang_nhap[tmp].name, user);
    // tmp++;
    char buff[1000] = {};
    char query_string[] = {"INSERT INTO user (user_name, pass, win,isInGame,isLogin ) VALUES('%s', '%s', '0', '0', '0')"};
    if (mysql_real_connect(con, "localhost", "root", "Pass1234@", "login", 0, NULL, 0) == NULL)
    {
        printf("loi\n");
        finish_with_error(con);
    }
    sprintf(buff, query_string, user, pass);
    printf("\n%s\n", buff);
    if (mysql_query(con, buff))
    {
        finish_with_error(con);
    }
}

// int main()
// {
//     MYSQL *con = mysql_init(NULL);
//     MYSQL *con1 = mysql_init(NULL);

//     char cauhoi[100], dapan[100];
//     // insert_data(con, "hieu", "1234");
//     // if (mysql_query(con, "INSERT INTO cars VALUES(5,'Bentley',350000)"))
//     // {
//     //     finish_with_error(con);
//     // }
//     cau_hoi(con, cauhoi, dapan);
//     for (int i = 0; i < 100; i++)
//     {
//         if (ch[i].lv == 0)
//         {
//             break;
//         }
//         printf("%s :[%s] :[%d]\n", ch[i].ques, ch[i].dapan, ch[i].lv);
//     }
//     // printf("%s\n%s\n", cauhoi, dapan);
//     mysql_close(con);
//     exit(0);
// }