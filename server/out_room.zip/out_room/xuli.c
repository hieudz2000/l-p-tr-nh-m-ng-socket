#include <string.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>

int xuli(char *string, char *user, char *pass)
{

    char *p;
    p = strtok(string, "#");
    for (int i = 0; i < 3; i++)
    {
        p = strtok(NULL, "#");

        if (p != NULL)
        {
            if (i == 0)
            {
                strcpy(user, p);
            }
            else if (i == 1)
            {
                strcpy(pass, p);
            }
            else
            {
                return 1;
            }
        }
        else
        {
            break;
        }
    }

    return 0;
}

int tim_diem(char *mang, int *b)
{
    char a[1000] = "result_after_turning#vi tri cua player#diem o chu quay trung#chu cai nhap vao#so lan dung#diem sau vong nay#ket qua hien sau vong nay#vi tri cua thang den luot tiep theo#end_round#id cua thang cuoi(gui cho ca 3 thang";
    char mang1[1000];
    strcpy(mang1, mang);
    char *token = strtok(mang1, "#");
    for (int i = 0; i < 5; i++)
    {
        token = strtok(NULL, "#");
    }
    // printf("%s\n", token);
    *b = atoi(token);
    printf("token:%d\n", *b);
}

int xet_diem(int x, int y, int z)
{
    if (x > y && x > z)
    {
        // printf("1\n");
        return 1;
    }
    else if (y >= x && y > z)
    { // thang thu 2 co the lon hon hoac bang thang thu nhat, do chs it luot hon
        // printf("2\n");
        return 2;
    }
    else
        // printf("3\n");
        return 3;
}

int send_cuoi(char *aa, char *bb)
{
    char data[1000];
    char mang1[1000], mang2[1000];
    strcpy(data, aa);
    printf("data vao: %s\n", data);
    int k = 0;
    for (int i = 0; i < strlen(data); i++)
    {
        mang1[i] = data[i];
        if (data[i] == '#')
        {
            k++;
            if (k == 7)
            {
                for (int j = i; j < strlen(data); j++)
                {
                    mang2[j - i] = data[j];
                }
                break;
            }
        }
    }
    mang1[strlen(mang1) - 2] = '\0';
    memset(aa, '\0', 1000);
    strcpy(aa, mang1);
    strcat(aa, bb);
    strcat(aa, mang2);
    printf("mang1: %s\n", mang1);
    printf("mang2: %s\n", mang2);
}