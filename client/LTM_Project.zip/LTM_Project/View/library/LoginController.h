//
// Created by hainguyen on 29/12/2021.
//

#ifndef LTM_PROJECT_LOGINCONTROLLER_H
#define LTM_PROJECT_LOGINCONTROLLER_H

#include "structScreen.h"
#include "handleMain.h"


void on_login_clicked(GtkButton *button, UserData *userData);
void on_register_clicked(GtkButton *button, UserData *userData);

#endif //LTM_PROJECT_LOGINCONTROLLER_H
