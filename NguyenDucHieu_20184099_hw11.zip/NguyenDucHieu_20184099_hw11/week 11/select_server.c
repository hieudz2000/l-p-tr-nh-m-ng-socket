#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>

#define PORT 5510  /* Port that will be opened */
#define BACKLOG 20 /* Number of allowed connections */
#define BUFF_SIZE 1024
char ab[100000];
/* The processData function copies the input string to output */
void processData(char *in, char *out);
void xuli2(char *in, int k, int i);
void xuli1(char *in, int *x, int *y);
void xuli3(int i, int k);
/* The recv() wrapper function*/
int receiveData(int s, char *buff, int size, int flags);
void xuli4(int s, int x, int y);
/* The send() wrapper function*/
int sendData(int s, char *buff, int size, int flags);
int khoa[10], prifix[10];
char mang[10][10][40];
char server_file[10][10][40];
int main()
{
	int i, maxi, maxfd, listenfd, connfd, sockfd;
	int nready, client[FD_SETSIZE];
	ssize_t ret;
	fd_set readfds, allset;
	char sendBuff[BUFF_SIZE], rcvBuff[BUFF_SIZE];
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;

	//Step 1: Construct a TCP socket to listen connection request
	if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{ /* calls socket() */
		perror("\nError: ");
		return 0;
	}

	//Step 2: Bind address to socket
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	if (bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)
	{ /* calls bind() */
		perror("\nError: ");
		return 0;
	}

	//Step 3: Listen request from client
	if (listen(listenfd, BACKLOG) == -1)
	{ /* calls listen() */
		perror("\nError: ");
		return 0;
	}

	maxfd = listenfd; /* initialize */
	maxi = -1;		  /* index into client[] array */
	for (i = 0; i < FD_SETSIZE; i++)
		client[i] = -1; /* -1 indicates available entry */
	FD_ZERO(&allset);
	FD_SET(listenfd, &allset);

	//Step 4: Communicate with clients
	while (1)
	{
		readfds = allset; /* structure assignment */
		nready = select(maxfd + 1, &readfds, NULL, NULL, NULL);
		if (nready < 0)
		{
			perror("\nError: ");
			return 0;
		}

		if (FD_ISSET(listenfd, &readfds))
		{ /* new client connection */
			clilen = sizeof(cliaddr);
			if ((connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &clilen)) < 0)
				perror("\nError: ");
			else
			{
				printf("You got a connection from %s\n", inet_ntoa(cliaddr.sin_addr)); /* prints client's IP */
				for (i = 0; i < FD_SETSIZE; i++)
					if (client[i] < 0)
					{
						client[i] = connfd; /* save descriptor */
						break;
					}
				if (i == FD_SETSIZE)
				{
					printf("\nToo many clients");
					close(connfd);
				}

				FD_SET(connfd, &allset); /* add new descriptor to set */
				if (connfd > maxfd)
					maxfd = connfd; /* for select */
				if (i > maxi)
					maxi = i; /* max index in client[] array */

				if (--nready <= 0)
					continue; /* no more readable descriptors */
			}
		}

		int k = 0;
		for (i = 0; i <= maxi; i++)
		{ /* check all clients for data */
			if ((sockfd = client[i]) < 0)
				continue;
			while (1)
			{
				if (FD_ISSET(sockfd, &readfds))
				{
					memset(rcvBuff, '\0', (strlen(rcvBuff) + 1));
					ret = receiveData(sockfd, rcvBuff, BUFF_SIZE, 0);
					// if (strcmp(rcvBuff, "exit") == 0)
					// {
					// 	break;
					// }
					printf("data: %s\n", rcvBuff);
					xuli1(rcvBuff, &prifix[i], &khoa[i]);

					do
					{
						memset(rcvBuff, '\0', (strlen(rcvBuff) + 1));

						ret = receiveData(sockfd, rcvBuff, BUFF_SIZE, 0);
						if (rcvBuff[0] == '2')
						{
							if (rcvBuff[2] == '0')
							{
								break;
							}
						}
						xuli2(rcvBuff, k, i);
						printf("%s\n", mang[i][k]);
						k = k + 1;
					} while (1);
					k = k - 1;
					//printf("%d   \n", k);
					xuli3(i, k);
					xuli4(sockfd, i, k);
					if (ret <= 0)
					{
						FD_CLR(sockfd, &allset);
						close(sockfd);
						client[i] = -1;
					}

					// else
					// {
					// 	processData(rcvBuff, sendBuff);
					// 	sendData(sockfd, sendBuff, ret, 0);
					// 	if (ret <= 0)
					// 	{
					// 		FD_CLR(sockfd, &allset);
					// 		close(sockfd);
					// 		client[i] = -1;
					// 	}
					// }

					if (--nready <= 0)
						break; /* no more readable descriptors */
				}
			}
		}
	}

	return 0;
}

void xuli4(int a, int x, int k)
{
	int h = 1000000;
	char file[10] = "file/";
	char name[1000];
	for (int i = 0; i <= k; i++)
	{
		FILE *fp = fopen(mang[x][i], "r");
		if (fp == NULL)
		{
			continue;
		}
		else
		{
			memset(name, '\0', strlen(name));
			memset(ab, '\0', strlen(ab));
			fseek(fp, 0, SEEK_END);
			h = ftell(fp);
			fseek(fp, 0, SEEK_SET);
			fread(ab, h + 1, 1, fp);
			fclose(fp);
			strcpy(name, file);
			if (prifix[x] == 0)
			{
				strcat(name, "MA_HOA_");
			}
			else
			{
				strcat(name, "GIAI_MA_");
			}
			int ddd;
			strcat(name, server_file[x][i]);
			FILE *fp = fopen(name, "w");
			if (prifix[x] == 0)
			{
				for (int t = 0; t < strlen(ab) - 1; t++)

				{
					if (ab[t] >= 'a' && ab[t] <= 'z')
						ab[t] = 97 + (ab[t] - 97 + khoa[x]) % 26;
				}
			}
			else
			{
				for (int t = 0; t < strlen(ab) - 1; t++)
				{
					if (ab[t] >= 'a' && ab[t] <= 'z')
					{
						ddd = ab[t] - 97 - khoa[x];
						if (ddd < 0)
						{
							ddd += 26;
						}
						ab[t] = 97 + ddd % 26;
					}
				}
			}
			fprintf(fp, "%s", ab);
			fclose(fp);
		}
	}
}

void xuli3(int i, int k)
{
	for (int j = 0; j <= k; j++)
	{
		printf("mang: %s\n", mang[i][j]);
		FILE *fp = fopen(mang[i][j], "r");
		if (fp == NULL)
		{
			printf(" teo nua gui file %d nay loi :v\n", j);
		}
		else
		{

			fclose(fp);
			strcpy(server_file[i][j], mang[i][j]);
			for (int m = 0; m < strlen(server_file[i][j]); m++)
			{
				if (server_file[i][j][m] == '/')
				{

					for (int n = m; n < strlen(server_file[i][j]) - 1; n++)
					{
						server_file[i][j][n] = server_file[i][j][n + 1];
					}
					server_file[i][j][strlen(server_file[i][j]) - 1] = '\0';
				}
			}
			//printf("flie: %s\n", server_file[i][j]);
		}
	}
}

void xuli2(char *in, int k, int i)
{
	char *p;
	int h = 0;

	p = strtok(in, " ");
	while (p != NULL)
	{
		p = strtok(NULL, ",");
		if (p != NULL)
		{
			h++;
			p = strtok(p, " ");
			if (h == 2)
			{
				strcpy(mang[i][k], p);
				break;
			}
		}
	}
}

void xuli1(char *in, int *x, int *y)
{
	int k = 0;
	char *p;
	if (in[0] == '0' || in[0] == '1')
	{

		p = strtok(in, " ");

		*x = atoi(p);

		while (p != NULL)
		{

			p = strtok(NULL, ",");
			if (p != NULL)
			{
				k++;
				p = strtok(p, " ");
				if (k == 2)
				{
					*y = atoi(p);
				}
			}
		}
	}
}

void processData(char *in, char *out)
{
	strcpy(out, in);
}

int receiveData(int s, char *buff, int size, int flags)
{
	int n;
	n = recv(s, buff, size, flags);
	buff[n] = '\0';
	if (n < 0)
		perror("Error: ");
	return n;
}

int sendData(int s, char *buff, int size, int flags)
{
	int n;
	n = send(s, buff, size, flags);
	if (n < 0)
		perror("Error: ");
	return n;
}
