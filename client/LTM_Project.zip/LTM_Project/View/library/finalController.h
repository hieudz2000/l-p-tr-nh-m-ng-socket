//
// Created by dung on 16/01/2022.
//
#ifndef LTM_PROJECT_FINALCONTROLLER_H
#define LTM_PROJECT_FINALCONTROLLER_H
#include "structScreen.h"
#include "handleMain.h"
void onSubmitLastAnswer(GtkButton *button,UserData *userData);
void onSubmit3character(GtkButton *button,UserData *userData);
#endif //LTM_PROJECT_FINALCONTROLLER_H


