//
// Created by hainguyen on 02/01/2022.
//

#ifndef LTM_PROJECT_HANDLEGAME_H
#define LTM_PROJECT_HANDLEGAME_H

#include  "structScreen.h"

void sendResultAfterTurning(int sockFd,char *annoucement);

#endif //LTM_PROJECT_HANDLEGAME_H
