//
// Created by hainguyen on 30/12/2021.
//

#ifndef LTM_PROJECT_GAMECONTROLLER_H
#define LTM_PROJECT_GAMECONTROLLER_H

#include "structScreen.h"
#include "handleMain.h"

void on_turn_clicked(GtkButton *button, UserData *userData);
void on_submit_clicked(GtkButton *button, UserData *userData);
void on_out_to_main_clicked(GtkButton *button,UserData *userData);
void on_to_final_game_clicked(GtkButton *button, UserData *userData);


#endif //LTM_PROJECT_GAMECONTROLLER_H
