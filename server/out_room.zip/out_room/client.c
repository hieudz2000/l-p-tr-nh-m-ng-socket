// #include <stdio.h>
// #include <netinet/in.h>
// #include <arpa/inet.h>
// #include <sys/socket.h>
// #include <sys/types.h>
// #include <string.h>
// #include <pthread.h>
// #define TRUE 1
// #define SERVER_ADDR "127.0.0.1"
// #define SERVER_PORT 5503
// #define MAX_LEN_BUFF 1024
// char buff[MAX_LEN_BUFF + 1];

// void xuli(int a);
// int login(int a);
// void create_room(int a);
// void join_room(int a);
// void out_room(int a);
// void *recv_server(void *argv);
// int main()
// {
//     int client_sock;
//     struct sockaddr_in server_addr; /* server's address information */
//     int msg_len, bytes_sent, bytes_received;
//     //Step 1: Construct socket
//     client_sock = socket(AF_INET, SOCK_STREAM, 0);
//     int opt = TRUE;
//     if (setsockopt(client_sock, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0)
//     {
//         perror("setsockopt");
//     }
//     //Step 2: Specify server address
//     server_addr.sin_family = AF_INET;
//     server_addr.sin_port = htons(SERVER_PORT);
//     server_addr.sin_addr.s_addr = inet_addr(SERVER_ADDR);
//     //Step 3: Request to connect server
//     if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0)
//     {
//         printf("\nError!Can not connect to sever! Client exit imediately! ");
//         return 0;
//     }

//     xuli(client_sock);

//     return 0;
// }

// void *recv_server(void *argv)
// {
//     int socfd = (int *)argv;
// }

// void xuli(int client)
// {
//     if (login(client) == 2)
//     {
//         int a;
//         pthread_t b;
//         a = pthread_create(&b, NULL, recv_server, &client);

//     }
// }

// int login(int client)
// {
//     char user[100], pass[100];
//     printf("nhap tai khoan: ");
//     scanf("%s", user);
//     printf("nhap pass: ");
//     scanf("%s", pass);
//     char data[100];
//     sprintf(data, "login#%s#%s", user, pass);
//     if (send(client, data, 1024, 0) < 0)
//     {
//         printf("ko gui dc login\n");
//         return 1;
//     }
//     memset(data, '\0', 1024);
//     if (recv(client, data, 1024, 0) < 0)
//     {
//         printf("ko nhan dc phan hoi login\n");
//         return 1;
//     }
//     printf("server-login: %s\n", data);

//     return 2;
// }
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "xuli.c"
int main()
{
    char a[100];
    char mm[1000] = " result_after_turning#2#600#a#1#400#lina#end_round#800";
    send_cuoi(mm, "1");
    printf("mang cuoi: %s\n", mm);
}