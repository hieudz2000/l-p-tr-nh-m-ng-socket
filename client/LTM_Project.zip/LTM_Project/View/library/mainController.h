//
// Created by hainguyen on 29/12/2021.
//

#ifndef LTM_PROJECT_MAINCONTROLLER_H
#define LTM_PROJECT_MAINCONTROLLER_H

void on_join_random_room_clicked(GtkButton *button, UserData *userData);
void on_create_room_clicked(GtkButton *button, UserData *userData);
void on_join_room_clicked(GtkButton *button, UserData *userData);
void on_submit_in_main_clicked(GtkButton *button, UserData *userData);

#endif //LTM_PROJECT_MAINCONTROLLER_H
