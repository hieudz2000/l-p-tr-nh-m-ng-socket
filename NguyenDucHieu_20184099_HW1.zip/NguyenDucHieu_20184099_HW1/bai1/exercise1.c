#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char haz[10];
char haz2[10] ="PRSTWXYZ";

char haz1_1[5] = "STYZ";

char re[10] = "PSWYZ";
char Con[10] = "PRST";
int tmp = 2;

char haz1[5][15] ={"","Jets","Fog","Foam","Dry agent"  };
int xuli3(){
    if(strchr(re,haz[1]) != NULL){
        printf("Reactivity: can be violently reactive\n");
    }
    else{
        printf("Reactivity: can't be reactive\n");
    }

    if(strchr(haz1_1,haz[1]) != NULL ){

        if(tmp == 1){
            printf("Protection: BA for fire only\n");
        }
        else if(tmp == 0){
            printf("Protection: breathing apparatus, protective gloves for fire only\n");
        }
    }
    else{
        printf("Protection: full protective clothing must be worn\n");
    }
    if(strchr(Con,haz[1]) != NULL ){
        printf("Containment: the dangerous goods may be washed down to a drain with a large\n");

    }
    else{
        printf("Containment: a need to avoid spillages from entering drains or water courses.\n");
    }

    if(haz[2] == 'E'){
        printf("Evacuation: consider evacuation\n");
        printf("******************************************\n");
        return 1;
    }
    printf("Evacuation: not Evacuation\n");
    printf("******************************************\n");
    return 0;
}
int xuli2(){
    char a[10];

    if(strchr(haz1_1,haz[1]) != NULL ){
        do {
            printf("Is the %c reverse coloured?(yes/no)\n", haz[1]);
            scanf("%s", a);
            // printf("%s\n", a);
            
            // strlwr(a);
            // str
            if (strcmp((a) , "yes") == 0) {
                tmp = 1;
            }
            else if(strcmp((a) , "no") == 0){
                tmp = 0;
            }
            else{
                printf("yes or no ?? ok :v\n");
            }

        }while(tmp == 2);

    }
    printf("***Emergency action advice***\n");
    int aa = atoi(haz);
    // printf("%d\n", a);
    printf("Material: %s\n", haz1[aa]);
    xuli3();
    return 0;
}
int xuli1(){
    if(strlen(haz) > 4 || haz[0] < '1' || haz[0]> '4'){
        printf("Err: is not HAZCHEM");
        return 0;
    }
    else if(strlen(haz) == 3 && haz[2] != 'E'){
        printf("Err: is not HAZCHEM");
        return 0;
    }
    else if(strchr(haz2, haz[1]) == NULL){
        printf("Err: is not HAZCHEM");
        return 0;
    }
    xuli2();
    return 1;
}


int main() {
    printf("moi nhap: ");
    scanf("%s", haz);
    xuli1();
    return 0;
}