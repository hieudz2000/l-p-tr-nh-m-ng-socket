//
// Created by hainguyen on 02/01/2022.
//

#ifndef LTM_PROJECT_HANDLEROOM_H
#define LTM_PROJECT_HANDLEROOM_H

#include "structScreen.h"
#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <string.h>

void outRoom(int sockFd, UserData *userData);
void startGame(int sockFd, UserData *userData);

#endif //LTM_PROJECT_HANDLEROOM_H
